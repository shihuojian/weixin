Page({
  data: {
    methods: ['scale', 'rotate', 'translate', 'save', 'restore',
    'drawImage', 'fillText', 'fill', 'stroke', 'clearRect',
    'beginPath', 'moveTo', 'lineTo', 'rect', 'arc', 'quadraticCurveTo', 'bezierCurveTo', 'closePath',
    'setFillStyle', 'setStrokeStyle', 'setShadow', 'setFontSize', 'setLineCap', 'setLineJoin', 'setLineWidth', 'setMiterLimit']
  }, 
  onLoad: function () {

  },
  onReady: function () {

  },
  onShow: function () {

  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },
})